list = dir('./');

for i=2:numel(list)
    if length(list(i).name)>7
       name = list(i).name;
       load(name);
       results{1}.fps = 0;
       save(name,'results');
    end
end